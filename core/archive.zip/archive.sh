pushd /Users/rstefanov/Sysadmin/Personal/portfolio/core
zip -r archive.zip ./ -x '*.git*' '*venv*'
popd
