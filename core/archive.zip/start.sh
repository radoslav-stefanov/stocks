python3 manage.py runserver
